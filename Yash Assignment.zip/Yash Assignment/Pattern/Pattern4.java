class Pattern4
{
  public static void main(String[] args)
  {
    int n=0;
    for(int i=1;i<=5;i++)
    {
      for(int j=1;j<=i;j++)
      {
        n+=1;
        System.out.print(n);
        System.out.print(" ");
      }
     System.out.println();
     }
   
   }
}