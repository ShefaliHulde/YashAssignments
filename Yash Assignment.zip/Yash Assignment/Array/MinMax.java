class MinMax
{
 public static void main(String[] args)
 {
   int[] a=new int[]{20,50,10};
   int min,max;
   min=a[0];
   for(int j:a)
   { 
     if(j<min)
     min=j;
   }
   max=Integer.MIN_VALUE;
   for(int i:a)
   {
     if(i>max)
     max=i;
   }
  System.out.println("Maximum element is "+max+" and Minimum element is "+min);
  }
}     
