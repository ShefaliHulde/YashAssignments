class PrintSum
{
 public static void main(String[] args)
 {
  int[] a={6,10,3,1,2,7,9};
  int sum=0;
  for(int i=0;i<a.length;i++)
  {
   if(a[i]==6)
    {
      
        while(a[i]!=7)
        { 
         i++;
        }
         
      if(a[i]==7)
       i++;
                                                                                                    
     }
   
    sum+=a[i];
 
   }
 System.out.println(sum);
 }
}

