class RemoveDuplicate
{
  public static void main(String[] args)
  {
   int[] a={12,30,15,16,30};
   int n=a.length;
  
 for(int i=0;i<n-1;i++)
 {
  for(int j=i+1;j<n;j++)
  {
   if(a[i]==a[j])
   {  
     a[j]=a[n-1];
     n--;
   }
  }
 }
 for(int i=0;i<n-1;i++)
{
 for(int j=0;j<n-1-i;j++)
 {
  if(a[j]>a[j+1])
  { 
   int temp=a[j];
   a[j]=a[j+1];
   a[j+1]=temp;
  }
  }
 }
  System.out.println("Array after removing duplicate is: ");
  for(int i=0;i<n;i++)
  { 
   System.out.println(a[i]);
  }

 }
 }
     
   
