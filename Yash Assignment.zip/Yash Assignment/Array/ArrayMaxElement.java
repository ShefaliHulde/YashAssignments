class ArrayMaxElement
{
 public static void main(String[] args)
 {
  int[][] a=new int[3][3];
  int b=args.length;
  int k=0;
  if(b<9)
  {
   System.out.println("Enter 9 number");
  }
 else if(b==9)
  {
    for(int i=0;i<3;i++)
    {
     for(int j=0;j<3;j++)
     {
       a[i][j]=Integer.parseInt(args[k]);
       k++;
     }
   }
int max=Integer.MIN_VALUE;
 System.out.println("Given matrix is:");
 for(int i=0;i<3;i++)
 {
   for(int j=0;j<3;j++)
   {
if(a[i][j]>max)
max=a[i][j];
     System.out.print(a[i][j]+" ");
   }
  System.out.println();
 }
System.out.println("The max value is "+max);
}
}
}

