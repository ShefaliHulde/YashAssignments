class Array
{
  public static void main(String[] args)
  {
    int[] a=new int[]{10,20,30};
    int sum=0;
    double avg;
    for(int i=0;i<a.length;i++)
    {
      sum=sum+a[i];
    }
    avg=sum/a.length;
    System.out.println("Sum is"+sum+"avergage is"+avg);
  }
 
}
   
 