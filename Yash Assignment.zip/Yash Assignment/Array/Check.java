class Check
{
  public static void main(String[] args)
  {
    int[] a={1,4,2,4};
    int c=0;
    for(int i=0;i<a.length;i++)
    { 
      if(a[i]!=1 && a[i]!=4)
      {
        c=1;
        System.out.println("false");
      }
      
     }
  if (c==0)
    
   System.out.println("true");
  
  }
}
