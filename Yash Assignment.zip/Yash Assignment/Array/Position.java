class Position
{ 
 public static void main(String[] args)
 {
   int[] a={1,4,10,5};
   int index=-1;
   int b=Integer.parseInt(args[0]);

   for(int i=0;i<a.length;i++)
   {
     if(a[i]==b)
     {     
       index=i;
       break;
     } 
   }
if(index==-1)
 System.out.println(index);
else
  System.out.println("Element found at index position "+index);
  }
}