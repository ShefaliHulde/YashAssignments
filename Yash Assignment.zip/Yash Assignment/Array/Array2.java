class Array2
{
  public static void main(String[] args)
  {
    int[][] a={{10,20,30},{10,20,30}};
    int sum=0,t=0;
    double avg;
    for(int i=0;i<a.length;i++)
    {
      for(int j=0;j<3;j++)
      {
       sum=sum+a[i][j];
       t++;
      }
    }
  
    avg=sum/t;
    System.out.println("Sum is"+sum+"average is"+avg);
  }
 
}
  