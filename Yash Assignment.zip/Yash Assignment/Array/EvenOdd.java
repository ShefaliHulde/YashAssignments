class EvenOdd
{
 public static void main(String[] args)
 {
  int[] a={0,1,2,0,5};
   

  for(int i=0;i<a.length-1;i++)
  {
    if(a[i]%2==0 && i!=0)
    {
      int temp=a[i];
      a[i]=a[i-1];
      a[i-1]=temp;
    }
   }
 for(int i=0;i<a.length;i++)
  System.out.println(a[i]);
 }
}