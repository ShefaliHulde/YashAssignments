class ArrayLargestSmallest
{
 public static void main(String[] args)
 {
  
  int[] a={10,30,50,5,2,90};
  int n=a.length;
  for(int i=0;i<a.length-1;i++)
  {
    for(int j=0;j<a.length-1-i;j++)
    {
      if(a[j]>a[j+1])
      {
        int temp=a[j];
        a[j]=a[j+1];
        a[j+1]=temp;
      }
    }
  }
 System.out.println("Two Largest Elements are: "+a[n-1]+" and"+a[n-2]);
 System.out.println("Two Smallest Elements are: "+a[0]+" and"+a[1]);
 }
}