class MidElementArray
{
  public static void main(String[] args)
  {
   int[] a={1,2,3};
   int[] b={4,5,6};
   int a1=a.length/2;
   int b1=b.length/2;
   int[] c=new int[2];
   c[0]=a[a1];
   c[1]=b[b1];
 for(int i=0;i<c.length;i++)
  System.out.println(c[i]);
 }
}