import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.ListIterator;
import java.io.InputStreamReader;
import java.io.BufferedReader;
class A
{
	public String name;
	public String last_name;
	public String contact_number;
	public String address;
	public String takeName(String name,String last_name,String address,String contact_number)
	{
		this.name = name;
		this.last_name = last_name;
		this.contact_number = contact_number;
		this.address =address;
		return " Name = \t" + name + "\n Last Name = \t" + last_name + "\n Address = \t" + address +  "\t Contact Number = \t" + contact_number + "\n ";
	}
	
}
class ArrayListSelfPractice extends A
{
	public static void main(String[] args) throws Exception
	{
		A obj = new A();
		List<String> a = new ArrayList<String>(1);
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader brr = new BufferedReader(isr);
		System.out.println("How many deatils you want to Enter");
		int num = Integer.parseInt(brr.readLine());
		int i;
		
		for(i =1; i<= num; i++)
		{
			System.out.println("Enter the name");
			String name = brr.readLine();
			System.out.println("Enter the Lastname");
			String last_name = brr.readLine();
			System.out.println("Enter the address");
			String address = brr.readLine();
			System.out.println("Enter the contact_number");
			String contact_number = brr.readLine();
		
			
			a.add(obj.takeName(name,last_name,address,contact_number));
		}
		System.out.println("Forword direction");
		ListIterator li = a.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		
	
		

	}
	
}