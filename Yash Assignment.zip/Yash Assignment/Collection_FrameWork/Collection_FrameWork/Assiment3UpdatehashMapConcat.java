import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


class Contact
{
	String name;
	Integer Phone_number;
	Contact(String name,Integer Phone_Number)
	{
		this.name =name;
		this.Phone_number= Phone_Number;
	}
}
public class Assiment3UpdatehashMapConcat {
		
	public static void main(String[] args) throws Exception
	{
		InputStreamReader ir = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(ir);
		List<Contact> l = new ArrayList<Contact>();
		int i;
		for(i=1; i <= 2; i++)
		{
			System.out.println("Enter name and phoneNumberssa");
			String name= br.readLine();
			int phone_number = Integer.parseInt(br.readLine());
			Contact c = new Contact(name,phone_number);
			l.add(c);
		}
		
		System.out.println();
		System.out.println("Itretor");
		Iterator it = l.iterator();
		while(it.hasNext())
		{
			Contact ct= (Contact)it.next();
			
			System.out.println("name = " + (String)ct.name + " phone_number is = " + (Integer)ct.Phone_number );
		}
		
		System.out.println(l.size());
		for(Contact  a:l)
		{
			System.out.println(a);
		}
		
		
		
	}

}
