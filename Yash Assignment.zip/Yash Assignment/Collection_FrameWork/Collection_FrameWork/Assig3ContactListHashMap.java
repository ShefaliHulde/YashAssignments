import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Assig3ContactListHashMap {
	public static void main(String[] args) throws Exception,NumberFormatException
	{
		

	
	Map<String, Integer> hmap = new HashMap<String, Integer>();
	hmap.put("a", (int)989884);
	hmap.put("g", (int)98989938);
	hmap.put("f", (int)98889938);
	hmap.put("v", (int)98989938);
	hmap.put("c", (int) 98989938);
	
	InputStreamReader ir = new InputStreamReader(System.in);
	BufferedReader sc = new BufferedReader(ir);
	System.out.println("Enter the key to find");
	String key= sc.readLine();
	boolean k = hmap.containsKey(key);
	if(k == true)
	{
		System.out.println("Key is exit " + key);
	}
	else
	{
		System.out.println("Key is Not exit " + key);
	}
	
	
	System.out.println();
	System.out.println("Enter the value to find");
	Scanner scobj = new Scanner(System.in);
	int value =(int)scobj.nextInt();
	boolean v = hmap.containsValue((int)value);
	if(v == true)
	{
		System.out.println("value Exist");
	}
	else
	{
		System.out.println("Value does not Exits");
	}

	
	System.out.println();
	System.out.println("Iterat the loop through Map");
	Iterator i =  hmap.keySet().iterator();
	while(i.hasNext())
	{
		String keys = (String) i.next();
		System.out.println("Key is " + keys + " Values is = " + hmap.get(keys) );
	}
	}

}
