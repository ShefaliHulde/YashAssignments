import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.HashSet;
import java.util.Iterator;
class Assig6EmployeeNameHashset
{	

	public static void main(String[] args) throws Exception
	{
	InputStreamReader ir = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(ir);
	HashSet<String> hs = new HashSet<String>();
	System.out.println("Enter the Number of Employee");
	int size = Integer.parseInt(br.readLine());
	int i;
	for(i=1; i <= size; i++)
	{	
		System.out.println("Enter the Name");
		String emp_name= br.readLine();
		hs.add(emp_name);
		
	}
	System.out.println("Employe Name By Iterator HasSet Method");
	
	Iterator t = hs.iterator();
	while(t.hasNext())
	{
		System.out.println(t.next()  );
	}
	}	
}