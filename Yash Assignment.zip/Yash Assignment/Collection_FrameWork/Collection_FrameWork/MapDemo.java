import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer,String> mp = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enetr the how many data you want to add");
		int num = sc.nextInt();
		int i;
		for(i=1; i<= num; i++)		{
			System.out.println("Enter id");
			int id = sc.nextInt();
			System.out.println("Enter name");
			String name = sc1.nextLine();
			mp.put(id,name);
		}
		Set<Integer> keys = mp.keySet();
		for(int key:keys)
		{
			System.out.println(mp.get(key));
		}
		
		System.out.println("hash Map is =" + mp);
		Map<Integer,String> mp1 = new TreeMap<>(mp);
		System.out.println("Tree Map is =" + mp1);
		List<Object> l1 = new LinkedList<>();
	}
	
	
}
