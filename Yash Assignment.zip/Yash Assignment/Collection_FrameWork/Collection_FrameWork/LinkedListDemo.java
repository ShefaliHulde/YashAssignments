import java.util.LinkedList;
import java.util.Scanner;
import java.util.ListIterator;
class LinkedListDemo
{
	public static void main(String[] args)
	{
		LinkedList<String> ls = new LinkedList<String>();
		Scanner sc = new Scanner(System.in);
	
		System.out.println("How many Elements you want to Enter ");
		int size = sc.nextInt();
		int i;
		System.out.println("Enter the Elements");
		for(i=0; i<= size; i++)
		{
			String s = sc.nextLine();
			ls.add(s);
		}
		System.out.println();
		
		ListIterator li =ls.listIterator();
		while(li.hasNext())
		{
			System.out.print(li.next() + "\t");
		}
		System.out.println();
		
		System.out.println("Method  of Linked List ");
		System.out.println("Method  of Add");
		System.out.println();
		
		boolean ad = ls.add("v added sucessfully ");
	
		ls.addFirst("A added at First ");
		ls.addLast("A added at last");
		for(String i1:ls)
		{
			System.out.println(i1);
		}
	}
}