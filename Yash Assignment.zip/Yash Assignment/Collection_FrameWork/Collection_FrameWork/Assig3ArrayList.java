import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

class Assig3ArrayList
{
	public static void main(String[] args) throws Exception 
	{
		Vector<String> a = new Vector<String>();
		
		a.add("January");
		a.add("February ");
		a.add("March");
		a.add("April ");
		a.add("May");
		a.add("June ");
		a.add("July");
		a.add("August");
		a.add("September");
		a.add("October");
		a.add("November");
		a.add("December ");
		
	Iterator ir = a.iterator();
		System.out.println();
		System.out.println("By ForEach loop");
		for(String t:a)
		{
			System.out.print(t+ "\t");
		}
		System.out.println();
		System.out.println("By Itretive loop");
		while(ir.hasNext())
		{
			System.out.println(ir.next());
		}
		System.out.println();
		System.out.println(a.size());
	}
}