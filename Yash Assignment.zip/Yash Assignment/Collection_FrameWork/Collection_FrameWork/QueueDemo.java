import java.util.Queue;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
class QueueDemo
{
	public static void main(String[] args)
	{
		Queue<Integer> q = new LinkedList<Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number 5");
		int i;
		for(i =1; i <= 5; i++)
		{
			int num = sc.nextInt();
			q.add(num);
		}
		
		System.out.println("Iterator use ");
		System.out.println("Peek top First element in queue = "+ q.peek());
		Iterator iq=q.iterator();
		while(iq.hasNext())
		{
			System.out.println(iq.next());
		}
		System.out.println("Remove top First element in queue");
		q.poll();
		Iterator iq1=q.iterator();
		while(iq1.hasNext())
		{
			System.out.println(iq1.next());
		}
		System.out.println("Peek top First element in queue");
		System.out.println("Peek top First element in queue = "+ q.peek());
		Iterator iq2=q.iterator();
		while(iq2.hasNext())
		{
			System.out.println(iq2.next());
		}
		
	}
}