import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;



class Student
{
	String name;
	int id;
	int[] m = new int[10];
	
	void takeData(String name,int id,int m[])
	{
		this.name = name;
		this.id = id;
		this.m = m;
	}
	
	}
public class PracticeCollection {
	public static void main(String[] args) {
		Student obj = new Student();
		int a[] = new int[]{10,20,30,40};
		obj.takeData("Abc",79797,a);
		List<Student> lk = new LinkedList<Student>();
		lk.add(obj);
		System.out.println(lk.toString());
		
		Iterator i = lk.iterator();
		while(i.hasNext())
		{
			Student s = (Student)i.next();
			System.out.println("name = " + s.name + "\t id = " + s.id + "\t m is " + s.m[0] + "\t" + s.m[1] + "\t" + s.m[2] + "\t" +s.m[3] );
		}
		
		
	}
}
