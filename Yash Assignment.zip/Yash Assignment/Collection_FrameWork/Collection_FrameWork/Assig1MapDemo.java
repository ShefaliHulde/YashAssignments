import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Assig1MapDemo {
	public static void main(String[] args) throws IOException {
		Map map = new HashMap<Integer,String>();
		map.put(1,"India");
		map.put(2,"USA");
		map.put(3,"UAE");
		map.put(4,"Japan");
		InputStreamReader ir = new InputStreamReader(System.in);
		BufferedReader sc = new BufferedReader(ir);
		System.out.println("Enter the key to find");
		int key = Integer.parseInt(sc.readLine());
		boolean k = map.containsKey(key);
		if(k == true)
		{
			System.out.println("Key is exit" + key);
		}
		else
		{
			System.out.println("Key is Not exit" + key);
		}
		System.out.println();
		System.out.println("Enter the value to find");
		String value = sc.readLine();
		boolean v = map.containsValue(value);
		if(v == true)
		{
			System.out.println("Value is exit" + value);
		}
		else
		{
			System.out.println("value is Not exit " +value);
		}
		System.out.println();
		System.out.println("Iterat the loop through Iterator");
		Iterator i =  map.keySet().iterator();
		while(i.hasNext())
		{
			int keys = (int)i.next();
			System.out.println("Key is " + keys + " Values is = " + map.get(keys) );
		}
	}

}
