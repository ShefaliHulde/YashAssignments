import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class PatternMatchExtractNum
{
	public static void main(String[] args)
	{
	String s="adbs2344csdc";
	String regex="\\d+";
	Pattern pattern=Pattern.compile(regex);
	Matcher matcher=pattern.matcher(s);
	System.out.println("Digits are: ");
	
		while(matcher.find())
		{
			System.out.println(matcher.group()+" ");
		}
	
	}
}
