import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class MobileNumberRegex
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter mobile number: "); 
		String s=sc.next();
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(s);
		
		if(s.matches("[0-9]{10}"))
		{
			
			System.out.println("valid");
		}
		else
		{
			System.out.println("Not valid");
		}
	}
}
		