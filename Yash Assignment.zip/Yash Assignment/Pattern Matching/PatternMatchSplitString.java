import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class PatternMatchSplitString
{
	public static void main(String[] args)
	{
	String s="adbs2344\ncsdc\ngah";
	String[] a=s.split("\n+");
	Pattern pattern=Pattern.compile(regex);
	Matcher matcher=pattern.matcher(s);
		for(String a1:a)
		{
			System.out.println(a1);
		}
	
	}
}