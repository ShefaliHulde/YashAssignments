import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class ValidateDateRegex
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date:"); 
		String s=sc.next();
		String regex="\\d((1?[9{3}]){4})-(0?[7])-(2?[7])";
		if(s.matches("\\d((1?[9{3}]){4})-(0?[7])-(2?[7])"))
			{
				System.out.println("valid");
			}
			else 
			{
				System.out.println("not valid");
			}
	}
}