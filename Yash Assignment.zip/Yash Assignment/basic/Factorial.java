class Factorial
{
  public static void main(String[] args)
  {
    int a=Integer.parseInt(args[0]);
    //int b=Integer.parseInt(args[1]);
  
    int fact=1;
    for(int i=1;i<=a;i++)
     { 
      
      fact=fact*i;
     }
      System.out.println(fact);
  } 
}