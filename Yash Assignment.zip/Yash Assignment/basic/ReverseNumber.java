class ReverseNumber
{
 public static void main(String[] args)
 {
  int a=Integer.parseInt(args[0]);
  int t=a,rev=0;
  while(t>0)
  {
   int digit=t%10;
   rev=(rev*10)+digit;
   t=t/10;
  }
 System.out.println("Reverse of the number is:"+rev);
 }
}