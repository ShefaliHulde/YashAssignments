class PrintTable
{
 public static void main(String[] args)
{
 int a=Integer.parseInt(args[0]);
 int b=Integer.parseInt(args[1]);
 int c;
 for(int i=1;i<=b;i++)
 {
   c=a*i;
   System.out.println(c);
 }
}
}