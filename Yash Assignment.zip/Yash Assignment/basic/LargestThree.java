class LargestThree
{
 public static void main(String[] args)
{
 int a=Integer.parseInt(args[0]);
int b=Integer.parseInt(args[1]);
int c=Integer.parseInt(args[2]);
if(a>b)
{
 if(a>c)
 System.out.println("First");
 else if(c>a)
System.out.println("Third");
}
else if(b>c)
{if(b>a)
System.out.println("Second");
else if(c>b)
System.out.println("Third");
}
}
}
