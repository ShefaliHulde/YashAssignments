class Fibonacci
{
 public static void main(String[] args)
 {
   
   int n=Integer.parseInt(args[0]);
   int temp,a=1,b=1;
   for(int i=1;i<=n;i++)
   {
     temp=a+b;
     a=b;
     b=c;
     System.out.println(a);
     System.out.println(b);
     a=temp; 
    }
  }
}   