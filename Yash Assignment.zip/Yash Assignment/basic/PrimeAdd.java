class PrimeAdd
{
  public static void main(String[] args)
  {
    int a=Integer.parseInt(args[0]);
    int m=Integer.parseInt(args[1]);
    int sum=0;
int n=0;
    for(int i=a;i<=m;i++)
     {
       if((a%i)==0)
         {
            n++;
             
         }
if(n==2)
 sum=sum+a;
     
      }
System.out.println("Sum of Prime Numbers is:" +sum);
  }
}