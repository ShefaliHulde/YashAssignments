class Author
{
    private String name;
    private char gender;  
    private String email;

    Author (String name, char gender, String email)
    {
        this.name = name;
        this.gender = gender; 
        this.email=email;  
    }
   
    public String getName()
    {
        return name;  
    }
    public char getGender()
    {
        return gender;
    }
    public String getEmail()
    {
        return email;
    }
}
class Book  {

    private Author author;
    private String name;
    private int qtyInStock;
    private double price;

 
    Book(String name, int qtyInStock, double price)
    {
        this.author=new Author ("J k Rowling",'f',"abc@gmail.com");
        this.name = name;
        this.qtyInStock=qtyInStock;
        this.price = price;    
    }

    
    public Author getAuthorsName()
    {
        return this.author;
    }
    public String getName()
    {
        return name;
    }

    public int getQtyInStock(){
        return qtyInStock;
    }

    public double getPrice(){
        return price;
    }

  
    public void setAuthor(Author newAuthor)
    {
        author=newAuthor;
    }
    public void setName (String name)
    {
        this.name=name;
    }
    public void setQtyInStock(int qtyInStock)
    {
        this.qtyInStock=qtyInStock;
    }
    public void setPrice(double price){
        this.price=price;
    }

    public String toString(){
        return "Name: " + this.name + "\n"+"Author: " + author + "\n" +
               "quantity in stock: " + this.qtyInStock + "\n" + "Price: " + this.price;
    }
}
class EncapsulationProblem
{
    public static void main(String[]args)
    {  
    Book b=new Book("Highway", 99, 990);
    System.out.println(b.toString());
    }
 }