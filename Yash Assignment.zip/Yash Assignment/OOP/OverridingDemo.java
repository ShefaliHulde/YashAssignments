class Fruit
{
 String name;
 String taste;
 int size;
 void eat()
 {
  System.out.println("Fruit class");
 }
}
class Apple extends Fruit
{
 void eat()
 {
  System.out.println("The taste of apple is sweet");
 }
}
class Orange extends Fruit
{
 void eat()
 {
  System.out.println("The orange has a sweet-sour taste");
 }
}
class OverridingDemo
{
 public static void main(String[] args)
 {
  Fruit f1=new Fruit();
  f1.eat();
  Apple f2=new Apple();
  f2.eat();
  Orange f3=new Orange();
  f3.eat();
 }
}