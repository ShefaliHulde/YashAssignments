class Box
{
 int w, h1, d1;
 Box(int w, int h, int d)
 {
  this.w=w;
  h1=h;
  d1=d;
 }
 int calculate()
 {
  int vol=w*h1*d1;
  return vol;
 }
public static void main(String[] args)
{
 Box b=new Box(3,4,6);
 System.out.println(b.calculate());
}
}
 