class Person
{
 String name;
 String dateOfBirth;
 Person(String name,String dateOfBirth)
 { 
  this.name=name;
  this.dateOfBirth=dateOfBirth;
 }
}
class Teacher extends Person
{
 double salary;
 String subject;
 Teacher(String name,String dateOfBirth,double salary,String subject)
 {
  super(name,dateOfBirth);
  this.salary=salary;
  this.subject=subject;
 }
  void display()
 {
  System.out.println(name+" "+dateOfBirth+" "+salary+" "+subject);
 }
}
class Student extends Person
{
 int studentId;
 Student(String name,String dateOfBirth,int studentId)
 {
  super(name,dateOfBirth);
  this.studentId=studentId;
 }
}
class CollegeStudent extends Student
{
 String collegeName;
 String year;
 CollegeStudent(String name,String dateOfBirth,int studentId,String collegeName, String year)
 {
  super(name,dateOfBirth,studentId);
  this.collegeName=collegeName;
  this.year=year;
 }
 void display()
 {
  System.out.println(name+" "+dateOfBirth+" "+studentId+" "+collegeName+" "+year);
 }
}
class OverridingDemo1
{
 public static void main(String[] args)
 {
  Teacher t=new Teacher("shefali","23/03/1992",60000,"Maths");
  t.display();
  CollegeStudent c=new CollegeStudent("Ani","14/06/2000",101,"UIT","fourth");
  c.display();
 }
}
