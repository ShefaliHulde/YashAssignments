class Patient
{
 String patientName;
 double height;
 double weight;
 double computeBMI(double weight, double height)
 {
 this.weight=weight;
 this.height=height;
  double a=weight/(height*height);
return a;
}
public static void main(String[] args)
{
 String name=args[0];
 double w=Double.parseDouble(args[1]);
 double h=Double.parseDouble(args[2]);
 Patient p=new Patient();
 System.out.println("The BMI is:" +p.computeBMI(w,h));
 }
}