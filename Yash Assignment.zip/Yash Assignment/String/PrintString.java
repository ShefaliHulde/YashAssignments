import java.util.Scanner;

class PrintString
{
 public static void main(String[] args)
 {
  int mid;
  String s1="";
  Scanner input=new Scanner(System.in);
  System.out.println("Enter the string:");
  String s=input.nextLine();
  if(s.length()%2==0)
  {
    mid=s.length()/2;
    for(int i=0;i<mid;i++)
    {
      s1=s1+s.charAt(i);
    } 
    System.out.println(s1);
  }
 else
  System.out.println("null");
 }
}