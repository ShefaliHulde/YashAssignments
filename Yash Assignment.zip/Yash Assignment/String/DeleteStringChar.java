import java.util.Scanner;
class DeleteStringChar
{ 
 public static void main(String[] args)
 {
  Scanner input=new Scanner(System.in);
  System.out.println("Enter the string:");
  String s=input.nextLine();
  int a=s.length();
  String s1="";
  s1=s.substring(1,a-1);
  System.out.println(s1);
 
 }
}