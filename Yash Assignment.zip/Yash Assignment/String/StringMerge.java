class StringMerge
{
 public static void main(String[] args)
 {
  String s1=args[0];
  String s2=args[1];
  StringBuffer str=new StringBuffer();
  for(int i=0;i<s1.length() || i<s2.length();i++)
  {
   if(i<s1.length())
    str.append(s1.charAt(i));
   if(i<s2.length())
    str.append(s2.charAt(i));
  }
  System.out.println(str);
 }
}