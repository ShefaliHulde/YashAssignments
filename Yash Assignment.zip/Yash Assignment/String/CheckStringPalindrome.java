import java.util.Scanner;

class CheckStringPalindrome
{
 public static void main(String[] args)
 {
  String rev="";
  Scanner input=new Scanner(System.in);
 System.out.println("Enter the string:");
 String s=input.nextLine();

 for(int i=s.length()-1;i>=0;i--)
 {
   rev=rev+s.charAt(i);
 }
 if(s.compareToIgnoreCase(rev)==0)
  System.out.println("palindrome");
else
 System.out.println("not a palindrome");
}
}

