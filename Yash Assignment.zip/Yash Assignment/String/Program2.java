class Program2
{ 
 public static void main(String[] args)
 {
  String s1="  Hello";
  System.out.println(s1);
  System.out.println(s1.trim());
 }
}