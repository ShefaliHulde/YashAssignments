class Program7
{
 public static void main(String[] args)
 {
  String s1="Hello World";
  System.out.println(s1.substring(2,7));
 }
}