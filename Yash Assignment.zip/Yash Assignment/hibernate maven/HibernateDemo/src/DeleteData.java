import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class DeleteData {
public static void main(String[] args) {
	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
  
SessionFactory factory = meta.getSessionFactoryBuilder().build();  
Session session = factory.openSession();  
	
try {

Transaction transaction = session.beginTransaction();
int id = 1;
Object object = session.load(Employee.class, id);
session.delete(object);
transaction.commit();
System.out.println("Employee record of Id=" + id+ " is deleted successfully");
} catch (HibernateException e) {
e.printStackTrace();
} finally {
session.close();
}
}
}