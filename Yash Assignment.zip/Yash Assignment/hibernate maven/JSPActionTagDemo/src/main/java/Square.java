
public class Square {
 public int sqr(int a)
 {
	 return a*a;
 }
}
