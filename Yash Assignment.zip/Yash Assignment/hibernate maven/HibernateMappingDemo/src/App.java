import javax.transaction.Transaction;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class App {
	public static void main(String[] args) {    
	      
	    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	    org.hibernate.Transaction tx=null;
	     
	    try {
	    tx=session.beginTransaction();   
	      
	    Employee e1=new Employee();    
	    e1.setFirstName("Shefali");    
	    e1.setLastName("Hulde");
	    e1.setSalary(2000);    
	        
	    Address address1=new Address();    
	    address1.setStreet("Bhel");    
	    address1.setCity("Bhopal");    
	    address1.setState("MP");    
	      
	    address1.setPincode(462022);    
	        
	    e1.setAddress(address1);    
	    address1.setEmployee(e1);    
	        
	    session.persist(e1);    
	    tx.commit(); 
	    }
	    catch(HibernateException e)
	    {
	    	if(tx!=null)tx.rollback();
	    	e.printStackTrace();
	    }
	      
	    finally
	    {
	    session.close();    
	    System.out.println("success");   
	    }
	}    
}
