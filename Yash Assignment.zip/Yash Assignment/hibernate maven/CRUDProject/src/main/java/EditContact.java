

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditContact
 */
@WebServlet("/EditContact")
public class EditContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		request.getRequestDispatcher("nav.jsp").include(request, response);
		PrintWriter out=response.getWriter();
		out.print("<br><br>"); 
		out.print("<style>span{display:inline-block;width:600px;height:500px;text-align:left;padding:7px;border:3px solid black;border-radius:10px;font-size:13;background-color:teal;}</style>");
		out.println("<center><span><br><h4 style='background-color:white'><center>Update Contact</center></h4>");
		String sid=request.getParameter("id");  
	     int id=Integer.parseInt(sid);  
	     Contact c=ContactDao.getContactById(id);  
		
		
		out.print("<center><form action='RetrieveEditContact' method='post'>");  
        out.print("<center><br><br><table id='contact'><br>");  
        out.print("<tr><td></td><td><br><br><br><input type='hidden' name='id' value='"+c.getId()+"' /></td></tr>");  
        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='"+c.getName()+"' disabled/></td></tr>");  
        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"+c.getEmail()+"' required/></td></tr>"); 
        out.print("<tr><td>Mobile:</td><td><input type='text' name='mobile' value='"+c.getMobile()+"'required/></td></tr>"); 
        out.print("<tr><td>Country:</td><td>");  
        out.print("<select name='country' required>");  
        out.print("<option>India</option>");  
        out.print("<option>USA</option>");  
        out.print("<option>Canada</option>");  
        out.print("<option>UK</option>");  
        out.print("</select>");  
        out.print("</td><td>");  
       
        out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save'/></td></tr>");  
        out.print("</table></center>");  
        out.print("</form></center></span></center>");  
          
        out.close();  
	}

}
