

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteTable
 */
@WebServlet("/DeleteTable")
public class DeleteTable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("nav.jsp").include(request, response);
		out.print("<title>View</title>");
		out.println("<center><h3>Contact List</h3></center>");
		List<Contact> list=ContactDao.getAllContact();
		out.print("<style>#contact {font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 80%;}#contact td, #contact th {border: 1px solid #ddd;padding: 8px;}#contact tr:nth-child(even){background-color: #f2f2f2;}#contact tr:nth-child(odd){background-color: #C0C0C0;}#contact tr:hover {background-color: #ddd;}#contact th {padding-top: 12px;padding-bottom: 12px;text-align: left;background-color:#383838;color: white;}</style>");
		out.print("<center><table id='contact' border='2' width='70%'");
		out.print("<tr><th>ID</th><th>Name</th><th>Mail</th><th>Mobile</th><th>Country</th><th>Gender</th><th>Delete</th></tr>");
		  for(Contact c:list) {
		  out.print("<tr><td>"+c.getId()+"</td><td>"+c.getName()+"</td><td>"+c.getEmail()+"</td><td>"+c.getMobile()+"</td><td>"+c.getCountry()+"</td><td>"+c.getGender()+"</td><td><a href='DeleteContact?id="+c.getId()+"'>delete</a></td></tr>");
		  }		
		 out.print("</table></body></center>");  
	}

}
