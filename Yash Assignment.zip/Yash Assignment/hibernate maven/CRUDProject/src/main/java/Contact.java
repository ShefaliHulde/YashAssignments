
public class Contact {
private String name,email,mobile,gender,country;
private int id;  

public int getId() 
{  
    return id;  
}  
public void setId(int id) 
{  
    this.id = id;  
}  
public void setName(String name)
{
	this.name=name;
}
public String getName()
{
	return name;
}

public void setEmail(String email)
{
	this.email=email;
}
public String getEmail()
{
	return email;
}
public void setMobile(String mobile)
{
	this.mobile=mobile;
}
public String getMobile()
{
	return mobile;
}
public void setGender(String gender)
{
	this.gender=gender;
}
public String getGender()
{
	return gender;
}
public void setCountry(String country)
{
	this.country=country;
}
public String getCountry()
{
	return country;
}

}
