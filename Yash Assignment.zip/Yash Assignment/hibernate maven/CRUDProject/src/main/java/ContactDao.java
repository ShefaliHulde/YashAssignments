import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ContactDao {
	public static Connection getConnection(){
		Connection connection = null;
	try {
		String connectionURL = "jdbc:mysql://localhost:3306/shefali";
		Class.forName("com.mysql.cj.jdbc.Driver");
	    connection = DriverManager.getConnection(connectionURL, "root", "root");

	    }
	catch(Exception ex){
	System.out.println(ex);
	}
	return connection;
	}
	public static int save(Contact e)
	{
	 int status=0;
	 try{
		 Connection connection=ContactDao.getConnection();
		 PreparedStatement ps=connection.prepareStatement("insert into contact(name,email,mobile,country,gender) values(?,?,?,?,?)");
		 ps.setString(1,e.getName());
		 ps.setString(2,e.getEmail());
		 ps.setString(3,e.getMobile());
		 ps.setString(4,e.getCountry());
		 ps.setString(5,e.getGender());
		 
		 status=ps.executeUpdate();
		 connection.close();
		 
	    }
	 catch(Exception ex)
	 {
		 ex.printStackTrace();
	 }
	 return status;
	}
	
	public static Contact getContactById(int id){  
        Contact c=new Contact();  
          
        try{  
            Connection connection=ContactDao.getConnection();  
            PreparedStatement ps=connection.prepareStatement("select * from contact where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                c.setName(rs.getString(1));    
                c.setEmail(rs.getString(2)); 
                c.setMobile(rs.getString(3));
                c.setCountry(rs.getString(4));
                c.setGender(rs.getString(5));
                c.setId(rs.getInt(6));
            }  
            connection.close();  
        }
        catch(Exception ex)
         {
        	ex.printStackTrace();
         }  
          
        return c;  
    }  
	
	
	public static List<Contact> getAllContact()
	{
		List <Contact> list=new ArrayList<Contact>();
		try
		{
			Connection connection=ContactDao.getConnection();
			PreparedStatement ps=connection.prepareStatement("select * from contact");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Contact c=new Contact();
				c.setName(rs.getString(1));
				c.setEmail(rs.getString(2));
				c.setMobile(rs.getString(3));
				c.setCountry(rs.getString(4));
				c.setGender(rs.getString(5));
				c.setId(rs.getInt(6));
				list.add(c);
			}
			connection.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	public static int delete(int id){ 
		int status=0;
		try
		{
			Connection connection=ContactDao.getConnection();
			PreparedStatement ps=connection.prepareStatement("delete from contact where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			
			connection.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return status;
	}
	
	public static int update(Contact c)
	{
		int status=0;
		try {
			Connection connection=ContactDao.getConnection();
			PreparedStatement ps=connection.prepareStatement("update contact set email=?,mobile=?,country=? where id=?");
			//ps.setString(1,c.getName());  
            ps.setString(1,c.getEmail());  
            ps.setString(2,c.getMobile());
            ps.setString(3,c.getCountry());
            //ps.setString(4,c.getGender()); 
            ps.setInt(4,c.getId());  
              
            status=ps.executeUpdate();  
              
            connection.close();  
        }
		catch(Exception ex)
		{
			ex.printStackTrace();
		}  
          
        return status;  
      }  
}


