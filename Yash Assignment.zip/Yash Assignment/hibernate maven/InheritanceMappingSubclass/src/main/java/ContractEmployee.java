
public class ContractEmployee extends Employee {
 private String contractDuration;
 private float payPerHour;
public String getContractDuration() {
	return contractDuration;
}
public void setContractDuration(String contractDuration) {
	this.contractDuration = contractDuration;
}
public float getPayPerHour() {
	return payPerHour;
}
public void setPayPerHour(float payPerHour) {
	this.payPerHour = payPerHour;
}
}
