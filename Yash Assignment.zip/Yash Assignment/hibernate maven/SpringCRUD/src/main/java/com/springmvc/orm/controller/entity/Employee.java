package com.springmvc.orm.controller.entity;

import javax.persistence.*;


@Entity
@Table(name="employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;


	@Column(name="name")
	private String name;
	
	@Column(name="email")
	private String Email;
	@Column(name="pass")
	private String pass;
	
	
	

	public Employee() {
	}
	
	public Employee(int id,String name, String email, String pass) {
		super();
		this.id = id;
		this.name = name;
		Email = email;
		this.pass = pass;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "Employee [ id ="+ id + "name=" + name + ", Email=" + Email + ", pass=" + pass + "]";
	}
	
	
}
