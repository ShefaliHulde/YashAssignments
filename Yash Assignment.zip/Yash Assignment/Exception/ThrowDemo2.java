import java.util.Scanner;
import java.util.InputMismatchException;
class ArithmeticExceptionDemo extends RuntimeException
{
 ArithmeticExceptionDemo(String s)
 {
  super(s);
 }
}

class ThrowDemo2
{
 public static void main(String[] args)
 {
  Scanner sc= new Scanner(System.in);
  System.out.println("Enter two integer number:");
  int a=sc.nextInt();
  int b=sc.nextInt();
  try
 {
  if(b==0)
  {
    throw new ArithmeticException("Invalid format");
  }
  else
  {
   int c=a/b;
   System.out.println(c);
  }
 }
 catch(ArithmeticException e)
 {
  e.printStackTrace();
 }
 finally
 {
  System.out.println("Inside finally block");
 }
}
}