import java.util.Scanner;
class Exception2
{
 public static void main(String[] args)
 {
  
  Scanner sc= new Scanner(System.in);
  System.out.println("Enter the number of elements in the array:");
  int b=sc.nextInt();
  int[] a=new int[b];
  System.out.println("Enter array elements:");
  for(int i=0;i<b;i++)
  {
    a[i]=sc.nextInt();
  }
  try
  {
   System.out.println("Enter the array index:");
   int c=sc.nextInt();
   
   int s=a[c];
    System.out.println("Array element at index:"+s);
  }
 catch(java.lang.ArrayIndexOutOfBoundsException e)
 {
  System.out.println("Enter correct index");
 }
}
}