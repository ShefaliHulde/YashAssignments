import java.util.Scanner;
class Exception1
{
 public static void main(String[] args)
 {
  int a;
 Scanner sc= new Scanner(System.in);
  try
  {
   System.out.println("Enter a number: ");
   a=sc.nextInt();
   System.out.println("Square value is: "+a*a); 
   }
  catch(java.util.InputMismatchException e)
 {
  System.out.println("Enetered input is not valid format for an integer");
}
}
}