import java.util.Scanner;
class NumberFormat extends RuntimeException
{
 NumberFormat(String s)
 {
  super(s);
 }
}
class ThrowDemo1
{
 public static void main(String[] args)
 {
  Scanner sc= new Scanner(System.in);
  int sum1=0,sum2=0;
  double avg1=0,avg2=0;
 int[] a=new int[3];
 int[] b=new int[3];
try
 {
  System.out.println("Enter marks of first student");
  for(int i=0;i<3;i++)
 {
   a[i]=sc.nextInt();
    if(a[i]<0 || a[i]>100)
    {
      throw new NumberFormat("Enter correct format");
    }
 }
System.out.println("Enter marks of second student");
  for(int i=0;i<3;i++)
 {
   b[i]=sc.nextInt();
    if(b[i]<0 || b[i]>100)
    {
      throw new NumberFormat("Enter correct format");
    }
 }
 for(int i=0;i<3;i++)
 {
  sum1=sum1+a[i];
 }
 avg1=sum1/3; 
System.out.println("Sum of first is:"+sum1+" and avg is:"+avg1); 
 for(int i=0;i<3;i++)
 {
  sum2=sum2+b[i];
 }
 avg2=sum2/3;  
System.out.println("Sum of second is:"+sum2+" and avg is:"+avg2); 
}

catch(NumberFormat e)
{
 e.printStackTrace();
 }
}
}
