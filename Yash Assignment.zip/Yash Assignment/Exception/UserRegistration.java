import java.util.Scanner;
class InvalidCountryException extends RuntimeException
{
 InvalidCountryException(String s)
 {
  super(s);
 }
}

class UserRegistration
{
  String userName;
  String userCountry;

   void registerUser(String userName,String userCountry)
   {
    this.userName=userName;
    this.userCountry=userCountry;
  try 
   {
     if(!(userCountry.equalsIgnoreCase("India")))
     {
       throw new InvalidCountryException("User outside India cannot be registered");
     }
    else
     System.out.println("User registered");
   }

catch(InvalidCountryException e)
{
  e.printStackTrace();
}
}
 public static void main(String[] args)
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter user name:");
  String s=sc.nextLine();
  System.out.println("Enter user country:");
  
  String c=sc.next();
 
 UserRegistration r=new UserRegistration();
 r.registerUser(s,c);
 }
}
