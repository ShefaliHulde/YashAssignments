class Exception4
{
 public static void main(String[] args)
 {
  int[] a=new int[5];
  int k=0;
  int sum=0,c=0;
  float avg=0;
  
try
{
  for(int i=0;i<5;i++)
  {
    a[i]=Integer.parseInt(args[k]);
    k++;
 }
 for(int i=0;i<5;i++)
 {
  sum=sum+a[i];
  c++;
  }
avg=sum/c;
 }

catch(ArithmeticException e)
{
  System.out.println("Incorrect logic");
}
catch(NumberFormatException e)
{
 System.out.println("Not correct format");
 }
}
} 