import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileInputStream;

class Count1
{
 public static void main(String[] args) throws IOException
 {
	 int character=0,word=0,whiteSpace=0,line=0;
	 FileInputStream fin=new FileInputStream("d:/yash/yash.txt");
	 BufferedReader br=new BufferedReader(new FileReader("d:/yash/yash.txt"));
	        
	 String str;
	 Scanner sc=new Scanner(System.in);
	 
		 
	 while((str=br.readLine())!=null)
	 { 
         line+=1;
         for(int i=0;i<str.length();i++)
		 {
			 
            character+=1;
		 
		 if(str.charAt(i)==' ')
		 {
			 whiteSpace+=1;
		     word+=1;
		 }
		 if(str.charAt(i)=='.')
			 word++;
		 }
	 }
	 fin.close();
	 System.out.println("The count of character in the file is:"+character+"\ncount of word:"+word+"\ncount of whitespace is:"+whiteSpace+"\ncount of line:"+line); 
 }
}