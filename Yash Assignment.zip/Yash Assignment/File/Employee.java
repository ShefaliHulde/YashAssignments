import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Employee
{
 private String name;
 private String department;
 private String designation;
 private double salary;
  
  public void setName(String name)
  {
	  this.name=name;
  }
  public void setDepartment(String department)
  {
	  this.department=department;
  }
   public void setDesignation(String designationt)
  {
	  this.designation=designation;
  }
   public void setSalary(double salary)
  {
	  this.salary=salary;
  }
  
  public String toString()
  {
	  return name+" "+department+" "+designation+" "+salary;
  }
}
class EmployeeDetail extends Serializable
{
	public static void main(String[] args)
	{
		File f=new File("d:/yash/yash.txt");
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(f));
		Employee e=new Employee();
		
		out.write(e.setName("Shefali");
		out.close();
	}
}

 