import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;
class Employee implements Serializable
{
 private String name;
 private String department;
 private String designation;
 private double salary;
  
  public void setName(String name)
  {
	  this.name=name;
  }
  public void setDepartment(String department)
  {
	  this.department=department;
  }
   public void setDesignation(String designation)
  {
	  this.designation=designation;
  }
   public void setSalary(double salary)
  {
	  this.salary=salary;
  }
  
  public String toString()
  {
	  return name+" "+department+" "+designation+" "+salary;
  }
}
class EmployeeDetail
{
	public static void main(String[] args) throws IOException,ClassNotFoundException
	{
		String a,b,c;
		double d;
		Scanner sc=new Scanner(System.in);
		File f=new File("d:/yash/yash.txt");
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(f));
		Employee e=new Employee();
		System.out.println("Enter employee name:");
		a=sc.next();
		e.setName(a);
		System.out.println("Enter department:");
		b=sc.next();
		e.setDepartment(b);
		System.out.println("Enter designation:");
		c=sc.next();
		e.setDesignation(c);
		System.out.println("Enter salary:");
		d=sc.nextDouble();
		e.setSalary(d);
		out.writeObject(e);
		out.close();
		ObjectInputStream in=new ObjectInputStream(new FileInputStream(f));
		Employee e1=(Employee)in.readObject();
		System.out.println(e1);
		in.close();
	}
}

 