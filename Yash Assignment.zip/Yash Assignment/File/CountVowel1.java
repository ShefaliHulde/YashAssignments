import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileInputStream;
class CountVowel1
{
  public static void main(String[] args) throws IOException
  {
	  int vowelCount=0,aCount=0,eCount=0,iCount=0,oCount=0,uCount=0;
	  FileInputStream fin=new FileInputStream("d:/yash/yash.txt");
	  BufferedReader br=new BufferedReader(new FileReader("d:/yash/yash.txt"));
	   String str=br.readLine();
	  
	  for(int i=0;i<str.length();i++)
	  {
		  char ch=str.charAt(i);
		  if(ch=='a' ||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='O'||ch=='o'||ch=='U'||ch=='u')
		  {
			  vowelCount++;
			  {
				  if(ch=='a'||ch=='A')
					  aCount++;
				  else if(ch=='e'||ch=='E')
					  eCount++;
				  else if(ch=='i'||ch=='I')
					  iCount++;
				  else if(ch=='o'||ch=='O')
					  oCount++;
				  
				  else if(ch=='u'||ch=='U')
					  uCount++;
			  }
		  }
	  }
		  System.out.println("No of vowels are:"+vowelCount);
		  System.out.println("Count of a:"+aCount+"\nCount of e:"+eCount+"\nCount of i:"+iCount+"\nCount of o:"+oCount+"\nCount of u:"+uCount);
	  fin.close();
  }
}