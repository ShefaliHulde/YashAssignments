import java.util.Scanner;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.BufferedReader;
class CountCharacter
{
	public static void main(String[] args) throws IOException
	{
		int count=0;
		String s;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the file:");
		String file=sc.next();
		FileInputStream fin=new FileInputStream(file);
		System.out.println("Enter the character to be counted:");
		String a=sc.next();
		BufferedReader br=new BufferedReader(new FileReader(file));
		while((s=br.readLine())!=null)
		{
			for(int i=0;i<s.length();i++)
			{
				if(s.charAt(i)==a.charAt(0))
		        {
					count++;
				}
			}
		}
		fin.close();
		System.out.println("file "+file+" has "+count+" instances of letter "+a);
	}
}
			