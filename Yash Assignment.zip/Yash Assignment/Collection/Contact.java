import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

public class Contact
{
	public static void main(String[] args)
	{
	Map<String,Integer> map=new HashMap<String,Integer>();
	map.put("Shefali",9673188);
	map.put("yash",4675899);
	System.out.println(map.containsKey("Shefali"));
	System.out.println(map.containsValue(1568976));
	Set s=map.entrySet();
	Iterator i=s.iterator();
	while(i.hasNext())
	{
		Map.Entry entry=(Map.Entry)i.next();
		System.out.println("Key:"+entry.getKey()+" value:"+entry.getValue());
	}
    }
}