import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

public class Hashmap
{
	public static void main(String[] args)
	{
	Map<Integer,String> map=new HashMap<Integer,String>();
	map.put(1,"Shefali");
	map.put(2,"yash");
	System.out.println(map.containsValue("Shefali"));
	System.out.println(map.containsKey(1));
	Set s=map.entrySet();
	Iterator i=s.iterator();
	while(i.hasNext())
	{
		Map.Entry entry=(Map.Entry)i.next();
		System.out.println("Key:"+entry.getKey()+" value:"+entry.getValue());
	}
    }
}